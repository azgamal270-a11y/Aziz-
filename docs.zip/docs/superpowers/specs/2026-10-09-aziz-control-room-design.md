# Aziz Suite End-to-End Completion and Production Readiness

**Status:** Draft for user review  
**Date:** 2026-10-09

## Goal

Complete the customer-facing Aziz Suite as well as the Control Room. The Expo
mobile app and React/Vite dashboard must use the same Express API and
Drizzle/PostgreSQL database. Keep the existing OpenAPI code-generation and
Expo architecture. Do not replace the database or run Prisma migrations.
Audit and fix existing TypeScript, runtime, import, dependency, and build
configuration errors before declaring feature work complete.

## Confirmed decisions

- Admin has all day-to-day control-room access; super admin also controls
  staff-role provisioning and administrator grants.
- Support can access customer and order-care tools with limited permissions.
- Delivery staff can access assigned shipments and update shipping details only.
- Sellers remain in Seller Center and do not receive admin permissions.
- Shipping is one global fee and free-shipping threshold, initially `15 SAR` and
  `200 SAR` to preserve current API/checkout behavior.
- Customers may request returns up to 14 days after delivery, subject to
  applicable consumer-protection law and product-specific returnability.
- Android package ID: `com.aziz.marketplace`.
- Commission reports use recorded seller payout/commission ledger rows; reports
  must not invent or recalculate historical commission amounts.
- Cash on Delivery is the only enabled checkout method until another provider
  is configured and tested.
- Use decimal-safe server-side order calculations and the supplied 14% default
  tax rate; snapshot all totals on each order. Confirm the applicable tax rules
  before public release.

## Existing implementation findings

- The admin login starts with `email: ""`; `admin@aziz.com` is only a placeholder.
  Zod rejects the empty value before an API request. The server also performs
  case-sensitive email equality checks.
- The dashboard currently stores its bearer token in `localStorage`.
- Existing admin pages can list several resources, but categories are read-only,
  product approval and customer account controls are missing, and order
  operations are incomplete.
- The shared schema already has inventory transactions, payments, refunds,
  returns, seller payouts, and audit logs, but several have no admin API or UI.
- Products have no review status; sellers have only a Boolean approval state.
- Checkout uses a server fee/threshold of 15/200 SAR. The cart and product page
  display 29/300 SAR. Checkout also displays a sample address and offers card
  and Apple Pay even though the API rejects every non-COD method.
- Home products and categories use the API, while promotional banners are local
  hardcoded content.
- The mobile cart already uses the API for signed-in users, but it currently
  identifies items by product rather than a selected variant/size. Its current
  catch blocks can hide API failures from the customer.
- The current Expo `build` script produces static Expo Go bundles/manifests,
  not a signed Android App Bundle. `app.json` has no Android package ID and
  there is no EAS production profile.

## Architecture and authorization

1. Keep the OpenAPI specification as the source of truth for new API endpoints
   and regenerate shared clients after every contract change.
2. Enforce every permission on the API. Dashboard route visibility is only a
   convenience and is never the authorization boundary.
3. Use a centralized server permission map:
   - `ADMIN`: all day-to-day Control Room capabilities.
   - `SUPER_ADMIN`: all Control Room capabilities, including staff-role
     provisioning and administrator access grants.
   - `SUPPORT`: view customer/order details and reply to or resolve support
     tickets; no catalog, financial, shipping-configuration, order-state, or
     role-management writes.
   - `DELIVERY`: read and update only shipments explicitly assigned to that
     delivery user.
   - `SELLER` and `CUSTOMER`: no Control Room access.
   No user can grant themselves a role. Staff provisioning and role changes
   must be audited.
4. Preserve mobile bearer authentication. Store native mobile credentials in
   platform secure storage and migrate existing locally stored sessions on
   upgrade. For the browser dashboard, use an HttpOnly, Secure, SameSite
   session cookie rather than persisting an administrator bearer token in
   local storage. Add login rate limiting and origin/CSRF protection for
   cookie-authenticated mutations.
5. Normalize email input by trimming and lowercasing. Resolve case-insensitive
   account matches safely; if existing records collide under case-folding,
   fail closed and report the ambiguity rather than authenticating the wrong
   account. New registrations must prevent case-variant duplicates.
6. Bootstrap the first super admin through an operator-run CLI command. It
   prompts for email/password without echoing the password, hashes with the
   existing password-hashing library, acquires a database lock, and refuses
   to create an account if any admin already exists. No public bootstrap route,
   default credential, or authentication bypass is permitted.

## Control Room workflows

- **Dashboard:** real database counts and financial values in SAR; remove the
  existing AED formatter mismatch.
- **Staff access:** super admins can provision and disable support, delivery,
  and administrator accounts. Granting `SUPER_ADMIN` remains a separate,
  explicitly audited super-admin action.
- **Merchants:** search/list/detail, approve, reject, suspend, and reactivate.
  Use explicit states instead of conflating rejected/suspended merchants with
  pending sellers.
- **Customers:** search by name/email, view account and order history, and
  suspend/reactivate accounts. Never expose password hashes, payment secrets,
  or unnecessary customer data.
- **Support tickets:** support staff can review open tickets, send customer-facing
  replies, and resolve or reopen tickets. Ticket actions are audited; support
  cannot alter orders, payments, refunds, or customer roles.
- **Products:** queue seller submissions for review; approve/reject/suspend.
  Existing products remain approved during the additive migration so the
  current catalog stays visible. Public product APIs and mobile screens must
  exclude unapproved or suspended products.
- **Categories:** create, edit, and delete categories. Block deletion while
  products or child categories depend on the category.
- **Orders:** filter and inspect real order snapshots, update valid lifecycle
  states, assign delivery users, and edit tracking information. Preserve
  historical totals and avoid unsupported payment/refund transitions.
- **Inventory:** adjust product-level stock transactionally, update both the
  product stock shown to customers and the inventory ledger, and record actor,
  reason, and signed quantity. Do not directly alter variant stock that the
  current checkout does not consume.
- **Payments:** list payment records and accurately reconcile COD collection.
  Mark a COD payment paid only after staff confirm collection. Card/Apple Pay
  remain hidden until a real provider flow is configured and verified.
- **Returns/refunds:** customers can request returns from delivered orders
  within 14 days, selecting order items and quantities with a reason. Enforce
  ownership, delivery date, product returnability, and remaining refundable
  quantity in a transaction. Admins approve/reject and track receipt/refund
  states. A COD refund remains pending/manual until staff confirm an offline
  refund. A card refund is only complete after the real provider confirms it.
  Never report a fabricated successful refund.
- **Shipping:** configure the platform fee and free-shipping threshold.
  Calculate final totals on the server; expose the same settings/quote to
  mobile cart, product, and checkout screens. Settings apply to new orders;
  historical order fees do not change.
- **Commissions:** report actual payout ledger totals/statuses and date ranges.
  Empty ledgers render an explicit empty state.
- **Audit logs:** record actor, action, target, timestamp, safe metadata, and
  request IP for sensitive admin mutations. Provide a searchable, read-only
  admin audit page.
- **Banners:** store active/paused promotional banners in PostgreSQL. Admins can
  create, edit, reorder, schedule, and deactivate banners using image URLs.
  Mobile fetches active banners from the API; no local sample promotion is
  presented as live business content.

## Customer mobile app and shared marketplace workflows

- **Authentication and profile:** keep registration/login on the shared API,
  normalize email consistently, validate inputs on both client and server, and
  use secure native session storage. Preserve existing wishlist and review
  behavior while ensuring their data is scoped to the signed-in account.
- **Catalog:** fetch searchable products, categories, images, availability,
  seller details, and actual variant attributes from the API. Only approved,
  active products with valid stock are purchasable. Remove mock/demo content
  from all production paths.
- **Virtual fitting room:** keep the existing mobile fitting-room experience;
  use actual product size metadata and actual available variants. Collect
  height/weight with validated inputs, never recommend an unavailable size, and
  carry the selected variant/size from product detail through server cart and
  checkout. Do not substitute hardcoded size arrays.
- **Cart:** persist cart items against the signed-in customer in the shared
  database, keyed by the selected product variant. Recalculate displayed
  quantity, availability, price, and shipping quote from API data. Show API
  errors instead of silently swallowing failed changes.
- **Checkout:** use a real saved customer address; validate all fields and
  stock server-side. Show only Cash on Delivery for now. Recalculate subtotal,
  14% tax, shipping, discount, and grand total on the server using decimal-safe
  arithmetic; ignore client-submitted totals and persist an immutable order
  price snapshot. Use idempotency/concurrency protection to prevent duplicate
  orders and overselling.
- **Orders and returns:** show the authenticated customer's actual order
  history, items, shipping/tracking events, payment status, and return
  eligibility. Let customers submit the eligible return requests described in
  this spec and see each return and refund status change.
- **Customer care:** submit and follow real support tickets through the API;
  show replies and resolution status without exposing internal admin notes.
- **Synchronization:** after admin changes to product review, stock,
  categories, shipping, banners, or order state, mobile requests must read the
  updated server state. Invalidate affected caches; do not keep stale mock
  prices, availability, addresses, or banners.

## Database and data safety

Use additive Drizzle schema changes only. Preserve existing rows and historical
order/payment totals. Existing customers default active; existing products
backfill to approved; existing approved sellers remain approved and currently
unapproved sellers become pending because the old Boolean cannot distinguish
rejected from pending. New seller/product statuses are explicit.

Add only the missing persisted state required for this design, including
shipping settings, banner records, product/seller review states, account
activation, delivery assignments, return line items, and a delivery timestamp.
Use database constraints and transactional checks for unique settings/assignments,
return quantities, inventory, and case-insensitive emails. Migrations must not
drop tables or rewrite financial history. Existing delivered orders without a
reliable delivered timestamp require manual review rather than an invented
eligibility date.

Product-specific return exceptions are administrator-configurable. Do not
hardcode a list of legal exclusions. Returnability must be applied only where
allowed by the applicable consumer-protection rules.

## Mobile synchronization and Android release

- Keep product, category, order, cart, and banner reads/writes on the shared API.
- Use the server’s shipping quote/settings and totals throughout product,
  cart, and checkout displays.
- Use real saved customer addresses at checkout instead of the sample Riyadh
  address. Preserve the server as the authority for totals, stock, status, and
  eligibility.
- Remove unsupported card/Apple Pay choices until implemented end to end.
- Configure `com.aziz.marketplace`, Android version/build metadata, and an EAS
  production profile that builds an Android App Bundle. Use a production API
  origin, never a development domain. Signing credentials must remain in
  Expo/Replit secure credential storage and never enter source control.
- Distinguish Expo static-bundle checks from a signed `.aab` build. The latter
  requires an authenticated EAS project and release signing configuration;
  do not claim it passed unless an actual production profile build succeeds.
- Prepare a Google Play release checklist covering EAS project association and
  signing, production API configuration, app icon/screenshots, store listing,
  privacy policy and data-safety disclosures, content rating, target SDK,
  internal/closed testing, and final Play Console submission. Code/configuration
  can be prepared here; publishing requires the owner's Play Console account
  and approval.

## External configuration and service boundaries

- **Required for production operation:** a production PostgreSQL `DATABASE_URL`,
  a strong `SESSION_SECRET`, and a deployed HTTPS API origin configured into
  the mobile release. Keep each in Replit Secrets/EAS secure configuration as
  appropriate; never print them or commit them.
- **Required for a signed Android release:** an authenticated EAS project and
  Android signing credentials. The permanent package ID is
  `com.aziz.marketplace`.
- **Optional payment provider:** no card or Apple Pay option is advertised while
  only COD is implemented. Enabling card payments later requires a real provider
  account/credentials, server-side intent creation, verified webhook handling,
  real refunds, and tested end-to-end provider workflows. Until then, no card
  API key is required and no card success is simulated.
- **Banner images:** use HTTPS image URLs managed in the dashboard; no image
  hosting credential is necessary in this scope.

## Error handling and verification

- Show loading, empty, validation, permission-denied, and server-error states;
  do not silently swallow cart, address, or admin mutation failures.
- Invalidate/refetch affected queries after mutations so mobile and dashboard
  views converge on shared server state.
- Add tests for login normalization/ambiguity, bootstrap idempotency, each role
  boundary, form validation, approval visibility, real variant/size carry-through,
  inventory ledger consistency, shipping/tax consistency, checkout retries and
  stock races, address ownership, return eligibility and quantity races,
  COD/payment/refund state accuracy, banner activation, and audit writes.
- Verify the main customer paths (sign up/sign in, browse/search, choose an
  available size, add/update/remove cart items, choose an address, place a COD
  order, inspect tracking, request a return, submit/follow a support ticket)
  and admin paths (sign in, permissions, approve a product, adjust stock,
  manage orders/returns/refunds, change shipping/banner settings, inspect audit
  history).
- Verify existing Seller Center workflows remain available and cannot access
  Control Room-only records or actions.
- Run workspace typechecks, API/dashboard production builds, Expo Doctor,
  mobile Android and iOS production bundle checks, and API tests. Do not run
  destructive migrations or tests against production data. Run the authenticated
  EAS Android release build only after EAS credentials and production API
  configuration are available; report any remaining Play Console work as a
  checklist, not as published functionality.

## Implementation sequence

1. Capture baseline checks; fix existing type/runtime/import/dependency/build
   errors; then harden auth, email/form validation, first-admin setup, and role
   permission tests.
2. Additive database and OpenAPI contracts for catalog variants, checkout,
   shipping, returns, banners, and operational records; implement shared API
   behavior and audit writes.
3. Complete dashboard management pages for merchants, customers, staff,
   products, categories, orders, payments, inventory, returns, commissions,
   shipping, banners, and audits.
4. Complete customer mobile catalog, fitting room, cart, address/checkout,
   order/return experience against those same APIs.
5. Android production configuration, release build when credentials are
   available, Google Play checklist, and full verification.
