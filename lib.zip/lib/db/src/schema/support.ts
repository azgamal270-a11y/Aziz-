import { index, integer, pgTable, serial, text, timestamp, boolean } from "drizzle-orm/pg-core";

export const supportTicketsTable = pgTable(
  "support_tickets",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    orderId: text("order_id"),
    subject: text("subject").notNull(),
    status: text("status").notNull().default("open"),
    assignedTo: integer("assigned_to"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => ({
    userIdx: index("support_tickets_user_idx").on(table.userId, table.createdAt),
    assigneeIdx: index("support_tickets_assignee_idx").on(table.assignedTo, table.status),
  }),
);

export const supportTicketMessagesTable = pgTable(
  "support_ticket_messages",
  {
    id: serial("id").primaryKey(),
    ticketId: integer("ticket_id").notNull(),
    senderId: integer("sender_id").notNull(),
    body: text("body").notNull(),
    isInternal: boolean("is_internal").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    ticketCreatedIdx: index("support_ticket_messages_ticket_created_idx").on(
      table.ticketId,
      table.createdAt,
    ),
  }),
);
