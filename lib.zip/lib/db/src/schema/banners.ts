import { index, integer, pgTable, serial, text, timestamp, boolean } from "drizzle-orm/pg-core";

export const promotionalBannersTable = pgTable(
  "promotional_banners",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    imageUrl: text("image_url").notNull(),
    linkUrl: text("link_url"),
    isActive: boolean("is_active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    startsAt: timestamp("starts_at", { withTimezone: true }),
    endsAt: timestamp("ends_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => ({
    activeSortIdx: index("promotional_banners_active_sort_idx").on(
      table.isActive,
      table.sortOrder,
    ),
  }),
);
